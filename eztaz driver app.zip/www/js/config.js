/*EZ Taz App Configuration*/
var krms_driver_config ={		
	'ApiUrl':"http://eztaz.books2go.mobi/api",					
	'DialogDefaultTitle':"EZ Taz",	
	'PushProjectID':"953540851174",	
	'APIHasKey':"AIzaSyAv6fN4DAzFoZWwmexPMEJjqnpOLrDuhaw"
};